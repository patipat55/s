package com.example.shopeehelper

import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import com.google.android.material.textfield.TextInputEditText
import java.util.Calendar

class MainActivity : AppCompatActivity() {

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var linkInput: TextInputEditText
    private lateinit var timeInput: TextInputEditText
    private lateinit var optInput: TextInputEditText
    private lateinit var tvAccess: TextView
    private lateinit var tvStatus: TextView
    private lateinit var buyInput: TextInputEditText
    private lateinit var tvDump: TextView
    private lateinit var switchTest: SwitchMaterial

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        linkInput = findViewById(R.id.linkInput)
        timeInput = findViewById(R.id.timeInput)
        optInput = findViewById(R.id.optInput)
        tvAccess = findViewById(R.id.tvAccess)
        tvStatus = findViewById(R.id.tvStatus)
        buyInput = findViewById(R.id.buyTextInput)
        tvDump = findViewById(R.id.tvDump)
        switchTest = findViewById(R.id.switchTest)

        val prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        linkInput.setText(prefs.getString("link", ""))
        timeInput.setText(prefs.getString("time", ""))
        optInput.setText(prefs.getString("opts", ""))
        buyInput.setText(prefs.getString("buy", ""))
        switchTest.isChecked = prefs.getBoolean("test", true)

        findViewById<Button>(R.id.btnAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        findViewById<Button>(R.id.btnPaste).setOnClickListener { pasteLink() }
        findViewById<Button>(R.id.btnScan).setOnClickListener {
            if (!serviceEnabled()) {
                toast("ต้องเปิดสิทธิ์การช่วยเหลือพิเศษก่อน")
                return@setOnClickListener
            }
            Bot.dump = ""
            tvDump.text = "กำลังรอสแกน... สลับไปแอป Shopee ตอนนี้เลย"
            Bot.scanAt = System.currentTimeMillis() + 6000
        }
        findViewById<Button>(R.id.btnStart).setOnClickListener { start() }
        findViewById<Button>(R.id.btnStop).setOnClickListener {
            Bot.armed = false
            Bot.status = "หยุดแล้ว"
        }

        ui.post(object : Runnable {
            override fun run() {
                tvStatus.text = Bot.status
                if (Bot.dump.isNotEmpty()) tvDump.text = Bot.dump
                ui.postDelayed(this, 250)
            }
        })
    }

    override fun onResume() {
        super.onResume()
        updateAccessStatus()
    }

    private fun serviceEnabled(): Boolean {
        val enabled = Settings.Secure.getString(
            contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return enabled.contains("$packageName/${ShopeeBotService::class.java.name}")
    }

    private fun updateAccessStatus() {
        if (serviceEnabled()) {
            tvAccess.text = "✅ เปิดใช้งานแล้ว พร้อมทำงาน"
            tvAccess.setTextColor(Color.parseColor("#1B8A3A"))
        } else {
            tvAccess.text = "⚠️ ยังไม่ได้เปิด บอทจะกดอะไรไม่ได้จนกว่าจะเปิด"
            tvAccess.setTextColor(Color.parseColor("#C62828"))
        }
    }

    private fun pasteLink() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val txt = cm.primaryClip?.getItemAt(0)?.text?.toString()?.trim()
        if (txt.isNullOrEmpty()) {
            toast("คลิปบอร์ดว่าง ก๊อปลิงก์สินค้าจาก Shopee ก่อน")
        } else {
            linkInput.setText(txt)
        }
    }

    private fun looksLikeShopee(link: String): Boolean {
        val l = link.lowercase()
        return l.contains("shopee") || l.contains("shp.ee") || l.contains("shope.ee")
    }

    // ดึงเฉพาะ URL ออกมา เผื่อลิงก์ที่ก๊อปมามีข้อความแชร์ติดมาด้วย
    private fun extractUrl(text: String): String {
        val m = Regex("https?://\\S+").find(text)
        return m?.value ?: text
    }

    private fun start() {
        if (!serviceEnabled()) {
            toast("ยังไม่ได้เปิดสิทธิ์ ไปเปิด Shopee Flash Helper ในหน้าการช่วยเหลือพิเศษก่อน")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            return
        }

        val link = extractUrl(linkInput.text.toString().trim())
        if (link.isNotEmpty() && !looksLikeShopee(link)) {
            toast("ลิงก์นี้ไม่ใช่ลิงก์ Shopee")
            return
        }

        // เวลาเซล: ว่าง = เริ่มทันที
        var target = 0L
        val timeText = timeInput.text.toString().trim()
        if (timeText.isNotEmpty()) {
            val nums = timeText.split(":").map { it.toIntOrNull() }
            if (nums.size !in 2..3 || nums.any { it == null }) {
                toast("ใส่เวลาแบบ 12:00:00")
                return
            }
            val h = nums[0]!!
            val m = nums[1]!!
            val s = if (nums.size > 2) nums[2]!! else 0
            if (h > 23 || m > 59 || s > 59) {
                toast("เวลาไม่ถูกต้อง")
                return
            }
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, h)
                set(Calendar.MINUTE, m)
                set(Calendar.SECOND, s)
                set(Calendar.MILLISECOND, 0)
            }
            target = cal.timeInMillis
        }

        getSharedPreferences("cfg", Context.MODE_PRIVATE).edit()
            .putString("link", linkInput.text.toString().trim())
            .putString("time", timeText)
            .putString("opts", optInput.text.toString().trim())
            .putString("buy", buyInput.text.toString().trim())
            .putBoolean("test", switchTest.isChecked)
            .apply()

        Bot.targetMillis = target
        Bot.options = optInput.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
        Bot.extraBuy = buyInput.text.toString().split(",").map { it.trim() }.filter { it.isNotEmpty() }
        Bot.testMode = switchTest.isChecked
        Bot.syncNtp()
        Bot.status = "กำลังเปิดแอป Shopee..."
        Bot.armed = true

        if (!openShopee(link)) {
            Bot.armed = false
            Bot.status = "เปิดแอป Shopee ไม่ได้ ตรวจสอบว่าติดตั้งแอปแล้ว"
        }
    }

    private fun openShopee(link: String): Boolean {
        return try {
            if (link.isEmpty()) {
                val i = packageManager.getLaunchIntentForPackage("com.shopee.th")
                if (i == null) {
                    toast("ไม่พบแอป Shopee ในเครื่อง")
                    false
                } else {
                    startActivity(i)
                    true
                }
            } else {
                val uri = Uri.parse(link)
                val i = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.shopee.th") }
                try {
                    startActivity(i)
                } catch (e: ActivityNotFoundException) {
                    startActivity(Intent(Intent.ACTION_VIEW, uri))
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
}
