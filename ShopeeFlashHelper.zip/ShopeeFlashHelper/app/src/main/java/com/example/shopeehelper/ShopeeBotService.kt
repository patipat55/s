package com.example.shopeehelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

object Bot {
    @Volatile var armed = false
    @Volatile var targetMillis = 0L
    @Volatile var options: List<String> = emptyList()
    @Volatile var offsetMs = 0L
    @Volatile var status = "ยังไม่เริ่ม"

    // ถ้า Shopee เปลี่ยนข้อความ แก้ตรงนี้
    val buyTexts = listOf("ซื้อทันที", "ซื้อเลย", "Buy Now")
    val checkoutTexts = listOf("สั่งสินค้า", "สั่งซื้อ", "Place Order")
    val verifyHints = listOf("เลื่อน", "ลาก", "จิ๊กซอว์", "Slide", "puzzle", "verify")
    val packages = setOf("com.shopee.th")

    fun now() = System.currentTimeMillis() + offsetMs

    // ซิงก์เวลากับ NTP ของ Google
    fun syncNtp() = Thread {
        try {
            val s = DatagramSocket()
            s.soTimeout = 2000
            val buf = ByteArray(48)
            buf[0] = 0x1B
            val addr = InetAddress.getByName("time.google.com")
            val t0 = System.currentTimeMillis()
            s.send(DatagramPacket(buf, buf.size, addr, 123))
            s.receive(DatagramPacket(buf, buf.size))
            val t1 = System.currentTimeMillis()
            var secs = 0L
            for (i in 40..43) secs = (secs shl 8) or (buf[i].toLong() and 0xFF)
            var frac = 0L
            for (i in 44..47) frac = (frac shl 8) or (buf[i].toLong() and 0xFF)
            val serverMs = (secs - 2208988800L) * 1000 + frac * 1000 / 0x100000000L
            offsetMs = serverMs + (t1 - t0) / 2 - t1
            s.close()
        } catch (e: Exception) {
        }
    }.start()
}

class ShopeeBotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var waitingHuman = false
    private var bought = false
    private var lastOptionClick = 0L
    private var lastRefresh = 0L
    private var lastBuyClick = 0L
    private var wasArmed = false

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 40)
        }
    }

    override fun onServiceConnected() {
        handler.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun step() {
        if (!Bot.armed) {
            wasArmed = false
            return
        }
        if (!wasArmed) { // เพิ่งกดเริ่ม รีเซ็ตสถานะ
            wasArmed = true
            bought = false
            waitingHuman = false
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() !in Bot.packages) {
            Bot.status = "เปิดแอป Shopee ที่หน้าสินค้าค้างไว้"
            return
        }

        // 1) เจอหน้ายืนยันตัวตน -> หยุด ให้คนเลื่อนเอง
        if (hasVerify(root)) {
            if (!waitingHuman) {
                waitingHuman = true
                alert()
            }
            Bot.status = "เจอจิ๊กซอว์: เลื่อนเองได้เลย บอทหยุดรอ"
            return
        }
        waitingHuman = false

        val t = Bot.now()

        // 2) ก่อนเซล: เลือกสี/ไซส์ไว้ก่อน (ทุก 1 วิ)
        if (t < Bot.targetMillis) {
            Bot.status = "รออีก ${(Bot.targetMillis - t) / 1000} วินาที"
            if (t - lastOptionClick > 1000 && Bot.targetMillis - t > 300) {
                lastOptionClick = t
                Bot.options.forEach { clickText(root, listOf(it)) }
            }
            return
        }

        // 3) ถึงเวลา: กดซื้อ
        if (!bought) {
            if (clickText(root, Bot.buyTexts)) {
                bought = true
                Bot.status = "กดซื้อแล้ว กำลังไปหน้าชำระเงิน"
            } else {
                Bot.status = "รอปุ่มซื้อ..."
                if (t - lastRefresh > 1500) { // ปุ่มยังไม่ขึ้น: ดึงรีเฟรชหน้า
                    lastRefresh = t
                    Bot.options.forEach { clickText(root, listOf(it)) }
                    pullToRefresh()
                }
            }
            return
        }

        // 4) หน้าเช็กเอาต์: กดสั่งสินค้า แล้วหยุดให้คุณจ่ายเงินเอง
        if (clickText(root, Bot.checkoutTexts)) {
            Bot.status = "ถึงขั้นชำระเงินแล้ว: จ่ายเองได้เลย"
            Bot.armed = false
            alert()
            return
        }
        // ยังไม่ถึงหน้าเช็กเอาต์ (อาจเป็นแผ่นเลือกตัวเลือก): เลือกตัวเลือก + กดซื้อซ้ำทุก 0.7 วินาที
        if (t - lastBuyClick > 700) {
            lastBuyClick = t
            Bot.options.forEach { clickText(root, listOf(it)) }
            clickText(root, Bot.buyTexts)
        }
    }

    private fun hasVerify(root: AccessibilityNodeInfo): Boolean {
        for (h in Bot.verifyHints) {
            if (root.findAccessibilityNodeInfosByText(h)?.isNotEmpty() == true) return true
        }
        return false
    }

    private fun clickText(root: AccessibilityNodeInfo, texts: List<String>): Boolean {
        for (txt in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(txt) ?: continue
            for (n in nodes) {
                val label = n.text?.toString()?.trim()
                if (label != txt) continue
                var c: AccessibilityNodeInfo? = n
                while (c != null && !c.isClickable) c = c.parent
                if (c != null && c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
        }
        return false
    }

    private fun pullToRefresh() {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val p = Path().apply {
            moveTo(x, dm.heightPixels * 0.30f)
            lineTo(x, dm.heightPixels * 0.70f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 250))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun alert() {
        try {
            ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200)
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 300), -1))
        } catch (e: Exception) {
        }
    }
}
