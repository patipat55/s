package com.example.shopeehelper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress

object Bot {
    @Volatile var armed = false
    @Volatile var targetMillis = 0L
    @Volatile var options: List<String> = emptyList()
    @Volatile var offsetMs = 0L
    @Volatile var status = "ยังไม่เริ่ม"
    @Volatile var targetPrice = 0.0 // >0 = เลือกตัวเลือกอัตโนมัติจนราคาตรง
    @Volatile var testMode = true // โหมดทดสอบ: ไม่กดปุ่มสั่งซื้อจริง
    @Volatile var extraBuy: List<String> = emptyList() // ข้อความปุ่มซื้อที่ผู้ใช้ตั้งเอง
    @Volatile var scanAt = 0L // เวลาที่จะสแกนหน้าจอ (0 = ไม่สแกน)
    @Volatile var dump = ""

    // ถ้า Shopee เปลี่ยนข้อความ แก้ตรงนี้ หรือใส่ในช่อง "ข้อความปุ่มซื้อ" ในแอป
    val buyTexts = listOf("ซื้อเลย", "ซื้อทันที", "ซื้อด้วยโค้ด", "Buy Now")
    val checkoutTexts = listOf("สั่งสินค้า", "สั่งซื้อ", "Place Order")
    val verifyHints = listOf("เลื่อนเพื่อ", "ลากเพื่อ", "จิ๊กซอว์", "Slide to", "puzzle")
    val packages = setOf("com.shopee.th")
    // ข้อความที่มีคำว่า "ซื้อ" แต่ไม่ใช่ปุ่มซื้อ
    val buyExclude = listOf("สั่งซื้อ", "ซื้อแล้ว", "ซื้อไปแล้ว", "ซื้อซ้ำ", "วิธีซื้อ", "ผู้ซื้อ", "ซื้อคืน")

    fun buyList(): List<String> = extraBuy + buyTexts

    // โหมดเลือกตัวเลือกอัตโนมัติ: ใช้เมื่อตั้งราคาเป้าหมาย หรือไม่ได้ใส่ชื่อตัวเลือกเอง
    fun autoMode(): Boolean = targetPrice > 0 || options.isEmpty()

    fun now() = System.currentTimeMillis() + offsetMs

    // ซิงก์เวลากับ NTP ของ Google
    fun syncNtp() = Thread {
        try {
            val s = DatagramSocket()
            s.soTimeout = 2000
            val buf = ByteArray(48)
            buf[0] = 0x1B
            val addr = InetAddress.getByName("time.google.com")
            val t0 = System.currentTimeMillis()
            s.send(DatagramPacket(buf, buf.size, addr, 123))
            s.receive(DatagramPacket(buf, buf.size))
            val t1 = System.currentTimeMillis()
            var secs = 0L
            for (i in 40..43) secs = (secs shl 8) or (buf[i].toLong() and 0xFF)
            var frac = 0L
            for (i in 44..47) frac = (frac shl 8) or (buf[i].toLong() and 0xFF)
            val serverMs = (secs - 2208988800L) * 1000 + frac * 1000 / 0x100000000L
            offsetMs = serverMs + (t1 - t0) / 2 - t1
            s.close()
        } catch (e: Exception) {
        }
    }.start()
}

class ShopeeBotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var waitingHuman = false
    private var bought = false
    private var lastOptionClick = 0L
    private var lastRefresh = 0L
    private var lastBuyClick = 0L
    private var refreshedOnce = false
    private var wasArmed = false

    private val tick = object : Runnable {
        override fun run() {
            try {
                step()
            } catch (e: Exception) {
            }
            handler.postDelayed(this, 40)
        }
    }

    override fun onServiceConnected() {
        handler.post(tick)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun step() {
        handleScan()

        if (!Bot.armed) {
            wasArmed = false
            return
        }
        if (!wasArmed) { // เพิ่งกดเริ่ม รีเซ็ตสถานะ
            wasArmed = true
            bought = false
            waitingHuman = false
            refreshedOnce = false
            pickIdx = 0
            optionChosen = false
            loadTimeouts = 0
            loadingSince = 0L
            sheetSince = 0L
        }
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() !in Bot.packages) {
            Bot.status = "เปิดแอป Shopee ที่หน้าสินค้าค้างไว้"
            return
        }

        // 1) เจอหน้ายืนยันตัวตน -> หยุด ให้คนเลื่อนเอง
        if (hasVerify(root)) {
            if (!waitingHuman) {
                waitingHuman = true
                alert()
            }
            Bot.status = "เจอจิ๊กซอว์: เลื่อนเองได้เลย บอทหยุดรอ"
            return
        }
        waitingHuman = false

        val t = Bot.now()

        // 2) ก่อนเซล: เลือกสี/ไซส์ไว้ก่อน (ทุก 1 วิ)
        if (t < Bot.targetMillis) {
            Bot.status = "รออีก ${(Bot.targetMillis - t) / 1000} วินาที"
            if (t - lastOptionClick > 1000 && Bot.targetMillis - t > 300) {
                lastOptionClick = t
                Bot.options.forEach { clickText(root, listOf(it)) }
            }
            return
        }

        // 3) ถึงเวลา: กดซื้อ
        if (!bought) {
            if (Bot.autoMode() && autoPickStep(root, t)) return
            if (clickBuy(root)) {
                bought = true
                lastBuyClick = t
                Bot.status = "กดซื้อแล้ว กำลังไปหน้าสั่งซื้อ"
            } else {
                Bot.status = "รอปุ่มซื้อ... (ถ้านานเกินไป ใช้ปุ่มสแกนหน้าจอดูชื่อปุ่ม)"
                // รีเฟรชเฉพาะกรณีตั้งเวลาเซลไว้ และไม่รีเฟรชรัวๆ
                if (Bot.targetMillis > 0) {
                    if (!refreshedOnce) {
                        refreshedOnce = true
                        lastRefresh = t
                        pullToRefresh()
                    } else if (t - lastRefresh > 8000) {
                        lastRefresh = t
                        pullToRefresh()
                    }
                }
            }
            return
        }

        // 4) หน้าเช็กเอาต์
        if (Bot.testMode && hasText(root, Bot.checkoutTexts)) {
            // โหมดทดสอบ: ถึงหน้าสั่งซื้อแล้วหยุด ไม่กดปุ่มสั่งซื้อ
            Bot.status = "โหมดทดสอบ: ถึงหน้าสั่งซื้อแล้ว ไม่ได้กดสั่งซื้อ ✅"
            Bot.armed = false
            alert()
            return
        }
        if (!Bot.testMode && clickText(root, Bot.checkoutTexts)) {
            Bot.status = "ถึงขั้นชำระเงินแล้ว: จ่ายเองได้เลย"
            Bot.armed = false
            alert()
            return
        }
        // ยังไม่ถึงหน้าเช็กเอาต์ (อาจเป็นแผ่นเลือกตัวเลือก): เลือกตัวเลือก + กดซื้อซ้ำทุก 0.7 วินาที
        if (Bot.autoMode() && autoPickStep(root, t)) return
        if (t - lastBuyClick > 700) {
            lastBuyClick = t
            Bot.options.forEach { clickText(root, listOf(it)) }
            clickBuy(root)
        }
    }

    // ---------- เลือกตัวเลือกอัตโนมัติตามราคา (เช่น แคมเปญ 11 บาท) ----------
    private var pickIdx = 0
    private var lastPick = 0L
    private var lastAuto = 0L
    private var sheetPresent = false
    private val priceRegex = Regex("^฿?\\s*([0-9][0-9,]*(?:\\.[0-9]+)?)$")

    private fun allNodes(root: AccessibilityNodeInfo): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun go(n: AccessibilityNodeInfo?) {
            if (n == null) return
            out.add(n)
            for (i in 0 until n.childCount) go(n.getChild(i))
        }
        go(root)
        return out
    }

    private var optionChosen = false
    private var loadingSince = 0L
    private var loadTimeouts = 0
    private var sheetSince = 0L

    // ตัวเลือกที่กดได้บนแผ่นเลือกสินค้า (อยู่ระหว่างบรรทัด "คลัง" กับ "จำนวน") เรียงจากบนซ้ายไปล่างขวา
    private fun optionItems(nodes: List<AccessibilityNodeInfo>, sr: Rect, qr: Rect): List<AccessibilityNodeInfo> {
        val sw = resources.displayMetrics.widthPixels
        val items = ArrayList<Pair<AccessibilityNodeInfo, Rect>>()
        for (n in nodes) {
            if (!n.isClickable || !n.isVisibleToUser) continue
            val b = Rect()
            n.getBoundsInScreen(b)
            if (b.top >= sr.bottom - 5 && b.bottom <= qr.top + 5 && b.width() < sw * 0.9) items.add(Pair(n, b))
        }
        return items.sortedWith(compareBy({ it.second.top / 40 }, { it.second.left })).map { it.first }
    }

    // คืน true ถ้าอยู่บนแผ่นเลือกตัวเลือก (มี "คลัง" และ "จำนวน") และจัดการให้แล้ว
    private fun autoPickStep(root: AccessibilityNodeInfo, t: Long): Boolean {
        val real = System.currentTimeMillis()
        if (real - lastAuto < 150) return sheetPresent
        lastAuto = real

        val nodes = allNodes(root)
        val stock = nodes.firstOrNull { label(it).startsWith("คลัง") }
        val qty = nodes.firstOrNull { label(it) == "จำนวน" }
        if (stock == null || qty == null) {
            sheetPresent = false
            optionChosen = false
            loadingSince = 0L
            sheetSince = 0L
            return false
        }
        sheetPresent = true
        if (sheetSince == 0L) sheetSince = real

        // ค้างหน้าโหลด: เดิมรอไปเรื่อยๆ ไม่มีวันจบ -> ตอนนี้กดซื้อซ้ำ ถ้ายังค้างอีกก็ปิดแผ่นแล้วเริ่มใหม่
        if (nodes.any { label(it).contains("กำลังโหลด") }) {
            if (loadingSince == 0L) loadingSince = real
            val waited = real - loadingSince
            if (waited > 2500) {
                loadingSince = real
                loadTimeouts++
                if (loadTimeouts >= 3) {
                    loadTimeouts = 0
                    sheetSince = 0L
                    optionChosen = false
                    bought = false
                    Bot.status = "โหลดค้าง ปิดแผ่นแล้วกดซื้อใหม่"
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    return true
                }
                Bot.status = "โหลดค้าง กดซื้อซ้ำ (ครั้งที่ $loadTimeouts)"
                clickBuy(root)
            } else {
                Bot.status = "รอ Shopee โหลด..."
            }
            return true
        }
        loadingSince = 0L
        loadTimeouts = 0

        val sr = Rect()
        stock.getBoundsInScreen(sr)
        val qr = Rect()
        qty.getBoundsInScreen(qr)

        val want = Bot.targetPrice
        if (want > 0) return priceMode(root, t, nodes, sr, want)

        // ---- ไม่ได้ตั้งราคา: เลือกตัวเลือกที่กดได้ตัวแรกให้อัตโนมัติ แล้วกดซื้อรัวๆ ----
        val items = optionItems(nodes, sr, qr)
        if (items.isEmpty()) {
            // ไม่มีตัวเลือกให้เลือก (สินค้าตัวเดียว) กดซื้อเลย
            if (t - lastBuyClick > 300) {
                lastBuyClick = t
                if (clickBuy(root)) bought = true
            }
            Bot.status = "ไม่มีตัวเลือกให้เลือก กำลังกดซื้อ"
            return true
        }
        val enabled = items.filter { it.isEnabled }
        val pool = if (enabled.isNotEmpty()) enabled else items

        // อยู่บนแผ่นนานเกิน 4 วิ แปลว่าตัวเลือกนี้ซื้อไม่ได้ (หมด/ไม่ผ่าน) -> ลองตัวถัดไป
        if (optionChosen && real - sheetSince > 4000) {
            optionChosen = false
            pickIdx++
            sheetSince = real
        }
        if (!optionChosen) {
            val idx = pickIdx % pool.size
            tapNode(pool[idx])
            optionChosen = true
            Bot.status = "เลือกตัวเลือก ${idx + 1}/${pool.size} อัตโนมัติ"
            return true
        }
        if (t - lastBuyClick > 300) {
            lastBuyClick = t
            if (clickBuy(root)) bought = true
            Bot.status = "เลือกตัวเลือกแล้ว กำลังกดซื้อ..."
        }
        return true
    }

    // ---------- โหมดตั้งราคาเป้าหมาย (เช่น แคมเปญ 11 บาท) ----------
    private fun priceMode(root: AccessibilityNodeInfo, t: Long, nodes: List<AccessibilityNodeInfo>, sr: Rect, want: Double): Boolean {
        val qty = nodes.firstOrNull { label(it) == "จำนวน" } ?: return true
        val qr = Rect()
        qty.getBoundsInScreen(qr)

        // อ่านราคาที่แสดงอยู่เหนือบรรทัด "คลัง"
        var price: Double? = null
        var bestTop = Int.MIN_VALUE
        val pr = Rect()
        for (n in nodes) {
            val m = priceRegex.find(label(n)) ?: continue
            n.getBoundsInScreen(pr)
            if (pr.bottom <= sr.top + 5 && pr.top >= sr.top - 300 && pr.top > bestTop) {
                bestTop = pr.top
                price = m.groupValues[1].replace(",", "").toDoubleOrNull()
            }
        }

        val wantText = if (want % 1.0 == 0.0) want.toLong().toString() else want.toString()
        if (price != null && Math.abs(price - want) < 0.01) {
            Bot.status = "เจอตัวเลือกราคา ฿$wantText กำลังกดซื้อ"
            if (t - lastBuyClick > 300) {
                lastBuyClick = t
                if (clickBuy(root)) bought = true
            }
            return true
        }

        if (t - lastPick < 450) return true
        lastPick = t

        val sorted = optionItems(nodes, sr, qr)
        if (sorted.isEmpty()) {
            Bot.status = "ไม่พบตัวเลือกบนแผ่นเลือกสินค้า (ลองสแกนหน้าจอ)"
            return true
        }
        val idx = pickIdx % sorted.size
        pickIdx++
        tapNode(sorted[idx])
        val now = if (price != null) "ตอนนี้ ฿${if (price % 1.0 == 0.0) price.toLong() else price}" else "ยังไม่เห็นราคา"
        Bot.status = "ลองตัวเลือก ${idx + 1}/${sorted.size} หาราคา ฿$wantText ($now)"
        return true
    }

    // ---------- สแกนข้อความบนหน้าจอ (ไว้ดูชื่อปุ่มจริง) ----------
    private fun handleScan() {
        val at = Bot.scanAt
        if (at == 0L || System.currentTimeMillis() < at) return
        Bot.scanAt = 0L
        val root = rootInActiveWindow
        if (root == null) {
            Bot.dump = "อ่านหน้าจอไม่ได้"
            return
        }
        val sb = StringBuilder("แอปที่สแกน: ${root.packageName}\n\n")
        val cnt = intArrayOf(0)
        walk(root, sb, cnt)
        if (cnt[0] == 0) sb.append("ไม่พบข้อความบนหน้าจอ (แอปอาจบล็อกการอ่านหน้าจอ)")
        Bot.dump = sb.toString()
    }

    private fun walk(node: AccessibilityNodeInfo?, sb: StringBuilder, cnt: IntArray) {
        if (node == null || cnt[0] >= 200) return
        val t = node.text?.toString()?.trim().orEmpty()
        val d = node.contentDescription?.toString()?.trim().orEmpty()
        if (t.isNotEmpty() || d.isNotEmpty()) {
            cnt[0]++
            sb.append(if (node.isClickable) "[กดได้] " else "• ")
            sb.append(t)
            if (d.isNotEmpty() && d != t) sb.append(" | ").append(d)
            sb.append('\n')
        }
        for (i in 0 until node.childCount) walk(node.getChild(i), sb, cnt)
    }

    // ---------- ตัวช่วย ----------
    private fun hasVerify(root: AccessibilityNodeInfo): Boolean {
        for (h in Bot.verifyHints) {
            if (root.findAccessibilityNodeInfosByText(h)?.isNotEmpty() == true) return true
        }
        return false
    }

    // หาปุ่มที่มีคำว่า "ซื้อ" (เช่น ซื้อเลย, ซื้อด้วยโค้ด ...) เลือกอันที่กดได้และอยู่ล่างสุดของจอ
    private fun clickBuy(root: AccessibilityNodeInfo): Boolean {
        val cands = ArrayList<AccessibilityNodeInfo>()
        collectBuy(root, cands)
        if (cands.isEmpty()) return false
        val r = Rect()
        val sorted = cands.sortedWith(
            compareByDescending<AccessibilityNodeInfo> { hasClickable(it) }
                .thenByDescending { n -> n.getBoundsInScreen(r); r.top }
        )
        for (n in sorted) if (tapNode(n)) return true
        return false
    }

    private fun collectBuy(node: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>) {
        if (node == null) return
        val l = label(node)
        if (l.isNotEmpty() && l.length <= 60 && node.isVisibleToUser && isBuyLabel(l)) out.add(node)
        for (i in 0 until node.childCount) collectBuy(node.getChild(i), out)
    }

    private fun isBuyLabel(l: String): Boolean {
        if (Bot.buyExclude.any { l.contains(it, ignoreCase = true) }) return false
        if (Bot.extraBuy.any { l.contains(it, ignoreCase = true) }) return true
        return l.contains("ซื้อ") || l.contains("buy now", ignoreCase = true)
    }

    private fun hasClickable(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if (c.isClickable) return true
            c = c.parent
        }
        return false
    }

    private fun label(n: AccessibilityNodeInfo): String =
        (n.text?.toString() ?: n.contentDescription?.toString() ?: "").trim()

    private fun matches(n: AccessibilityNodeInfo, txt: String, exact: Boolean): Boolean {
        val l = label(n)
        return if (exact) l.equals(txt, ignoreCase = true) else l.contains(txt, ignoreCase = true)
    }

    private fun hasText(root: AccessibilityNodeInfo, texts: List<String>, exact: Boolean = true): Boolean {
        for (txt in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(txt) ?: continue
            if (nodes.any { matches(it, txt, exact) }) return true
        }
        return false
    }

    private fun clickText(root: AccessibilityNodeInfo, texts: List<String>, exact: Boolean = true): Boolean {
        for (txt in texts) {
            val nodes = root.findAccessibilityNodeInfosByText(txt) ?: continue
            for (n in nodes) {
                if (!matches(n, txt, exact) || !n.isVisibleToUser) continue
                if (tapNode(n)) return true
            }
        }
        return false
    }

    private fun tapNode(n: AccessibilityNodeInfo): Boolean {
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        if (c != null) {
            return c.isEnabled && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // ไม่มีตัวที่กดได้ -> แตะตามพิกัดกลางปุ่ม
        if (!n.isEnabled) return false
        val r = Rect()
        n.getBoundsInScreen(r)
        if (r.isEmpty) return false
        val p = Path().apply { moveTo(r.exactCenterX(), r.exactCenterY()) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        return dispatchGesture(g, null, null)
    }

    private fun pullToRefresh() {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val p = Path().apply {
            moveTo(x, dm.heightPixels * 0.30f)
            lineTo(x, dm.heightPixels * 0.70f)
        }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 250))
            .build()
        dispatchGesture(g, null, null)
    }

    private fun alert() {
        try {
            ToneGenerator(AudioManager.STREAM_ALARM, 100).startTone(ToneGenerator.TONE_CDMA_ALERT_CALL_GUARD, 1200)
            val v = getSystemService(VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 300), -1))
        } catch (e: Exception) {
        }
    }
}
